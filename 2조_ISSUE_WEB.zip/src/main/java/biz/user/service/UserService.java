package biz.user.service;

import java.util.List;
import biz.user.vo.UserVO;

public interface UserService {

	UserVO login(String id, String pw);
	int addUser(UserVO user) throws Exception;
	int IdChk(String userid) throws Exception;
	UserVO getUser(String userid); //한 명에 대한 데이터검색
	List<UserVO> getUserList();
	int updateUser(UserVO user);
	int removeUser(String userid);
	List<UserVO> searchUser(String condition, String keyword);

}
