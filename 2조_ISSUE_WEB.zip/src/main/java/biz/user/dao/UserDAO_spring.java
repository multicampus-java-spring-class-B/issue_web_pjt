package biz.user.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import biz.user.vo.UserVO;

@Component("spring")
public class UserDAO_spring implements UserDAO {

	@Autowired
	JdbcTemplate template;

	@Override
	   public UserVO login(String id, String pw) {
	      System.out.println("Spring DAO login");
	      
	      String sql = "select * from member where user_id=? and pw=?";
	      UserVO vo = null;

	      // queryForObject는 결과값이 하나 나오는 게 확정이라고 보고 쓰는 것
	      // queryForObject 사용했을때 로그인 실패하여 결과값이 하나도 없으면 예외가 발생한다
	      try {
	         vo = template.queryForObject(sql, new Object[] {id, pw}, new UserRowMapper());
	      }catch(Exception e) {
	    	  
	      }
	      return vo;
	   }

	@Override
	public int addUser(UserVO user) throws Exception {
		String sql = 
		"insert into member (user_id, pw, name, hp, sex) values (?, ?, ?, ?, ?)";

		return template.update(sql,user.getUser_id(), user.getPw(), user.getName(), user.getHp(), user.getSex());
	}

	@Override
	public UserVO getUser(String userid) {
		String sql = "select * from member where user_id = ?";
		UserVO vo = null;
		vo = template.queryForObject(sql, new Object[] {userid}, new UserRowMapper());
		return vo;
	}

	@Override
	public List<UserVO> getUserList() {
		System.out.println("Spring DAO...");
		String sql = "select * from member ";

		return template.query(sql, new UserRowMapper());
	}

	@Override
	public int updateUser(UserVO user) {
		 String sql = "update member set hp=?, sex=? "
		 		+ " where  user_id  = ? ";
		return template.update(sql, new Object[] {user.getHp(), user.getSex(), user.getUser_id()});
	}

	@Override
	public int removeUser(String userid) {
		System.out.println(userid+"다오");
		 String sql = "delete from member where  user_id  = ? ";
	
		return template.update(sql,new Object[] {userid});
	}

	@Override
	public List<UserVO> searchUser(String condition, String keyword) {
		System.out.println("지금 spring으로 동작중");
		String sql = "select * from member where upper("+condition+") like  '%'||?||'%'";
				 
		return template.query(sql,new Object[] {keyword} ,new UserRowMapper());
	}

	class UserRowMapper implements RowMapper<UserVO>{
		@Override
		public UserVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			UserVO vo = new UserVO();
			vo.setUser_id(rs.getString("user_id"));
			vo.setPw(rs.getString("pw"));
			vo.setName(rs.getString("name"));
			vo.setHp(rs.getString("hp"));
			vo.setSex(rs.getString("sex"));
			return vo;
		}
	}

	@Override
	public int idChk(String userid) throws Exception {
		String sql = "select count(*) from member where user_id = ? ";	//count가 열이름으로 부적합하다는 에러 
		int result = template.queryForObject(sql, Integer.class, userid);
		return result; 
	}
}