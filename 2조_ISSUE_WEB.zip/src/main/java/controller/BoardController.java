package controller;

import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import biz.boardlist.service.BoardListService;
import biz.boardlist.vo.BoardListVO;

@Controller
public class BoardController {

	@Autowired
	BoardListService service;

	//MAIN_JSON
		@RequestMapping("/jsonlist.do")
		@ResponseBody //ajax서버에서 사용할 서버
		public List<BoardListVO> jsonlist() {
			return service.getBoardNameList();
		}
	
	// 리스트 보여주기
	@RequestMapping("/board/list.do")
	public ModelAndView list() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("boardlists", service.getPostList());
		mav.setViewName("/board/board_list");

		return mav;
	}

	@RequestMapping(value = "/board/add.do", method = RequestMethod.GET)
	public String addPost() {
		return "board/board_write";
	}

	// 게시글 추가
	@RequestMapping(value = "/board/add.do", method = RequestMethod.POST)
	public String addBoardList(BoardListVO vo, HttpServletRequest req) throws Exception {
		System.out.println(vo);
		service.addPost(vo);

		return "redirect:/board/list.do";
	}
	
	@RequestMapping("/board/main.do")
	public String gotoMain() {
		return "index";
	}

	// 게시물 하나를 디테일하게 보기
	@RequestMapping("/board/view.do")
	public ModelAndView view(@RequestParam("post_id") int post_id) {

		ModelAndView mav = new ModelAndView();
		mav.addObject("boardlists", service.getPost(post_id));
		mav.setViewName("/board/board_view");

		return mav;
	}

	// 게시물 삭제하기
	@RequestMapping("/board/remove.do")
	public ModelAndView remove(String post_id) {
		service.removeBoardList(post_id);
		ModelAndView mav = new ModelAndView();
		mav.addObject("removecomplete", "removecomplete");
		mav.setViewName("/board/board_list");
		return mav;
	}

	// 게시물 수정하기
	@RequestMapping("/board/modify.do")
	public ModelAndView modify(@RequestParam("post_id") int post_id) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("boardlists", service.getPost(post_id));
		mav.setViewName("board/board_modify");

		return mav;
	}

	// 게시물 업데이트
	@RequestMapping("/board/update.do")
	public ModelAndView update(@ModelAttribute("boardlist") BoardListVO vo) {
		ModelAndView mav = new ModelAndView();
		service.updateBoardList(vo);
		System.out.println(vo);
		mav.addObject("boardlists", vo);
		mav.setViewName("board/board_view");

		return mav;
	}
	
	@RequestMapping("/search.do")
	public ModelAndView search(HttpServletRequest req) {
		String board_name = req.getParameter("slideindex");
		String search = req.getParameter("SearchText");
		List<BoardListVO> list = service.searchBoardlist(board_name, search);
		String listSize = Integer.toString(list.size());
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("search",search); //혹시몰라 이것도 넘겨줌
		mav.addObject("board_name", board_name); //혹시몰라 이것도 넘겨줌
		mav.addObject("listcnt", listSize);
		mav.addObject("boardlists", list);
		mav.setViewName("board/board_list");
		return mav;
	}
	
	@RequestMapping(value = "/board/search.do", method = RequestMethod.GET)
	public ModelAndView menuSearch(HttpServletRequest req) {
		String board_name = req.getParameter("board_name");
		List<BoardListVO> list = service.searchBoardlist(board_name, "");
		String listSize = Integer.toString(list.size());
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("board_name", board_name); //혹시몰라 이것도 넘겨줌
		mav.addObject("listcnt", listSize);
		mav.addObject("boardlists", list);
		System.out.println(list);
		mav.setViewName("board/board_list");
		return mav;
	}
	// error 처리
//   @ExceptionHandler(Exception.class)
//   public String ex(Exception e, Model model) {
//      model.addAttribute("Exception", e);
//      return "error";
//   }

}
